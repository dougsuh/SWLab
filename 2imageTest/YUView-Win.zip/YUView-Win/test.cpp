#include <fstream>
using namespace std;
const int X = 500, Y = 300;
int main() {
	unsigned char* yuvim,*y,*u,*v;
	ofstream xx("test.yuv", ios::binary | ios::out);
	yuvim = new unsigned char[X * Y * 3 / 2];
	y = yuvim;
	u = y + X * Y;
	v = u + X * Y / 4;
	for (int i = 0; i < Y; i++) {
		for (int j = 0; j < X; j++) y[i * X + j] = 0;
	}
	for (int i = 0; i < Y/2; i++) {
		for (int j = 0; j < X/2; j++) u[i * X/2 + j] = 0;
	}
	for (int frames = 0; frames < 100; frames++) {

		for (int i = 0; i < Y / 2; i++) {
			if (i > frames * 5 && i < frames * 5 + 10) {
				for (int j = 0; j < X / 2; j++) {
					v[i * X / 2 + j] = 255;
				}
			}
			else for (int j = 0; j < X / 2; j++) {
				v[i * X / 2 + j] = 0;
			}
		}
		xx.write((char*)yuvim, X * Y * 3 / 2);
	}
	xx.close();
	return 123;
}
